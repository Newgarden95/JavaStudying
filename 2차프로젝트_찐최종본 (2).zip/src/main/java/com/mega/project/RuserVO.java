package com.mega.project;

public class RuserVO {

	private String userid;
	private String userpw;
	private String username;
	private String usertel;
	private String useremail;
	private String userbirth;
	private String usergender;
	private String usertype;
	private String userroom;
	private String userinterest;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserpw() {
		return userpw;
	}
	public void setUserpw(String userpw) {
		this.userpw = userpw;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsertel() {
		return usertel;
	}
	public void setUsertel(String usertel) {
		this.usertel = usertel;
	}
	public String getUseremail() {
		return useremail;
	}
	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}
	public String getUserbirth() {
		return userbirth;
	}
	public void setUserbirth(String userbirth) {
		this.userbirth = userbirth;
	}
	public String getUsergender() {
		return usergender;
	}
	public void setUsergender(String usergender) {
		this.usergender = usergender;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getUserroom() {
		return userroom;
	}
	public void setUserroom(String userroom) {
		this.userroom = userroom;
	}
	public String getUserinterest() {
		return userinterest;
	}
	public void setUserinterest(String userinterest) {
		this.userinterest = userinterest;
	}

	
}
