package com.mega.project;

public class PlVO {
	String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "PlVO [address=" + address + "]";
	}
	
	
}
