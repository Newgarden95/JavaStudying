package com.mega.project;

public class PlVO {
	float latitude;
	float longtitude;
	
	public float getLatitude() {
		return latitude;
	}
	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}
	public float getLongtitude() {
		return longtitude;
	}
	public void setLongtitude(float longtitude) {
		this.longtitude = longtitude;
	}
	@Override
	public String toString() {
		return "PlVO [latitude=" + latitude + ", longtitude=" + longtitude + "]";
	}
}
