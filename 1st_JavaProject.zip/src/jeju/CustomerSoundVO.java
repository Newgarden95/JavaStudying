package jeju;

public class CustomerSoundVO {
	int customer_no;
	String customer_type;
	String customer_title;
	String customer_accommodation_name;
	String customer_date;
	String customer_writer;
	String customer_content;
	int customer_grade;
	public int getCustomer_no() {
		return customer_no;
	}
	public void setCustomer_no(int customer_no) {
		this.customer_no = customer_no;
	}
	public String getCustomer_type() {
		return customer_type;
	}
	public void setCustomer_type(String customer_type) {
		this.customer_type = customer_type;
	}
	public String getCustomer_title() {
		return customer_title;
	}
	public void setCustomer_title(String customer_title) {
		this.customer_title = customer_title;
	}
	public String getCustomer_accommodation_name() {
		return customer_accommodation_name;
	}
	public void setCustomer_accommodation_name(String customer_accommodation_name) {
		this.customer_accommodation_name = customer_accommodation_name;
	}
	public String getCustomer_date() {
		return customer_date;
	}
	public void setCustomer_date(String customer_date) {
		this.customer_date = customer_date;
	}
	public String getCustomer_writer() {
		return customer_writer;
	}
	public void setCustomer_writer(String customer_writer) {
		this.customer_writer = customer_writer;
	}
	public String getCustomer_content() {
		return customer_content;
	}
	public void setCustomer_content(String customer_content) {
		this.customer_content = customer_content;
	}
	public int getCustomer_grade() {
		return customer_grade;
	}
	public void setCustomer_grade(int customer_grade) {
		this.customer_grade = customer_grade;
	}
	

		
}
